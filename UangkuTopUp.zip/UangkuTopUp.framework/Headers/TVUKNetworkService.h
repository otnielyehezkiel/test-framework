//
//  TVUKNetworkService.h
//  UangkuTopUp
//
//  Created by Otniel Hutabarat on 19/09/18.
//  Copyright © 2018 Otniel Hutabarat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TVUKNetworkService : NSObject

- (void)testNetwork;

@end
